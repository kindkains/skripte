<html>
 <head>
  <title>PHP-Weiterleitung</title>
 </head>
 <body>i
 <?php header("location:http://Weiterleitung-zur-neuen-Domain.de"); ?>
 </body>
</html>
